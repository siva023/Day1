package com.example.session2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
